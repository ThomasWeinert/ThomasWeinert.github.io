<?php
//
// (c) Jan Wildeboer <jan.wildeboer@gmx.de>
//     Thomas Weinert <thomas@weaverslave.ws>
//     Andreas Habeck <andreas.habeck@stud.uni-karlsruhe.de>
//
// Put in the Public Domain by the Authors
//

define('TYPE_FUNCTION',  1);
define('TYPE_VAR',       2);
define('TYPE_CLASS',     3);
define('TYPE_DEFINE',    4);
define('TYPE_INCLUDE',   5);
define('TYPE_FILE',     20);

function getLineType($sLine)
{
  global $application;
  if ($sLine == '') {
    $application->showMessage('Line empty');
    return false;
  }
  if (preg_match("/^\s*function.*/i", $sLine)) {
    return TYPE_FUNCTION;
  } else if (preg_match("/^\s*var\s+/i", $sLine)) {
    return TYPE_VAR;
  } else if (preg_match("/^\s*class/i", $sLine)) {
    return TYPE_CLASS;
  } else if (preg_match("/^\s*define\s*\(/i", $sLine)) {
    return TYPE_DEFINE;
  } else if (preg_match("/^\s*(include|require)(_once)?\s*/i", $sLine)) {
    return TYPE_INCLUDE;
  } else if (preg_match('/^<\\?php/i', $sLine)) {
    return TYPE_FILE;
  }
  return false;
}


function getFunctionDetails($sLine)
{
  global $application;
  if (preg_match("/^\s*function\s+&{0,1}(\w+)\s*\(([^)]*)(.*)/i", $sLine, $result)) {
    return (array("functionname"=>$result[1], "params"=>$result[2]));
  } else {
    $application->showMessage('Did not match');
    return false;
  }
}

function getVarDetails($sLine)
{
  global $application;
  if (preg_match("/^\s*var\s+(\\\$\w+)\s*(\=\s*(['\"]|array|null|(\d+\s*;)|(\d+\.\d+\s*;))?)/i", $sLine, $result)) {
    $sValue = strtolower(trim($result[3]));
    if ($sValue == '') {
      $sVarType = 'mixed';
    } elseif ($sValue{0} == '"' || $sValue{0} == "'") {
      $sVarType = 'string';
    } elseif ($sValue == 'true' || $sValue == 'false') {
      $sVarType = 'string';
    } elseif ($sValue == 'null') {
      $sVarType = 'mixed';
    } elseif ($sValue == 'array') {
      $sVarType = 'array';
    } elseif (preg_match('/^\d+;$/', $sValue)) {
      $sVarType = 'integer';
    } elseif (preg_match('/^\d+\.\d+;$/', $sValue)) {
      $sVarType = 'float';
    } else {
      $sVarType = 'mixed';
    }
    return (array("varname"=>$result[1], "vartype"=>$sVarType));
  } else {
    $application->showMessage('Did not match');
    return false;
  }
}

function getFunctionParams($sSearch='')
{
  $aParams=array();
  $aRet=array();
  $aParams=explode(",",$sSearch);
  foreach($aParams as $sParam){
    $aTmp=explode("=",$sParam);
    if(isset($aTmp[1])){
      $sValue = strtolower(trim($aTmp[1]));
      if ($sValue == '') {
        $sVarType = 'mixed';
      } elseif ($aValue{0} == '"' || $sValue{0} == "'") {
        $sVarType = 'string';
      } elseif ($sValue == 'true' || $sValue == 'false') {
        $sVarType = 'boolean';
      } elseif ($sValue == 'null') {
        $sVarType = 'mixed';
      } elseif (preg_match('/^\d+$/', $sValue)) {
        $sVarType = 'integer';
      } elseif (preg_match('/^\d+\.\d+$/', $sValue)) {
        $sVarType = 'float';
      } else {
        $sVarType = 'mixed';
      }
      $aRet[trim($aTmp[0])]= array($sVarType, trim($aTmp[1]));
    } else {
      $aRet[trim($aTmp[0])]=1;
    }
  } // foreach
  return $aRet;
}

function getLineIndent($sLine)
{
  if (preg_match("/^(\s*)(var|class|function)/i", $sLine, $result)) {
    return strlen($result[1]);
  } else {
    return 0;
  }
}


$doc = $application->document();
if ($doc) {
  $content = $doc->text;
  $linestart = $doc->selstart-1;
  while (($linestart >= 0) && ($content{$linestart} != "\n")) {
    $linestart--;
  }
  $lineend = strpos($content, "\n", $linestart+1);
  $line = substr($content, $linestart+1, $lineend-$linestart-1);

  if(trim($line) != '') {

    $type = getLineType($line);
    if ($type == false) {
      $application->showMessage('No function, class, var, define, include or require.');
      return;
    }

    switch ($type) {

      case TYPE_FUNCTION :
        $aRet=getFunctionDetails($line);
        if($aRet == false){
          $application->showMessage('Function line not valid');
          return;
        } else {
          if($aRet['params']==''){
            $noParams=true;
          } else {
            $aParams=array();
            $aParams=getFunctionParams($aRet['params']);
            $noParams=false;
          }
          $phpdoc = "/"."**\n";
          $phpdoc .= "* \n";
          $phpdoc .= "*\n";
          if (!$noParams) {
            foreach($aParams as $key=>$value) {
              if (is_array($value)) {
                $phpdoc .= '* @param '.$value[0].' '.$key." optional, default value ".stripslashes($value[1])."\n";
              } else {
                $phpdoc .= '* @param '.$key."\n";
              }
            } // foreach
            $phpdoc .= "* \n";
          }
          $phpdoc .= "* @return \n";
          $phpdoc .= "*"."/\n";
        }
        break;

      case TYPE_VAR :
        $phpdoc = "/"."**\n";
        $phpdoc .= "* \n";
        $phpdoc .= "* @var ";
        if ($aRet = getVarDetails($line)) {
          $phpdoc .= $aRet['vartype'];
        }
        $phpdoc .= "\n";
        $phpdoc .= "*"."/\n";
        break;

      case TYPE_CLASS :
        $phpdoc = "/"."**\n";
        $phpdoc .= "* \n";
        $phpdoc .= "* \n";
        $phpdoc .= "* @author \n";
        $phpdoc .= "* @version \n";
        $phpdoc .= "*"."/\n";
        break;

      case TYPE_DEFINE :
        $phpdoc = "/"."**\n";
        $phpdoc .= "* \n";
        $phpdoc .= "*"."/\n";
        break;

      case TYPE_INCLUDE :
        $phpdoc = "/"."**\n";
        $phpdoc .= "* \n";
        $phpdoc .= "*"."/\n";
        break;

      case TYPE_FILE :
        if ($linestart <= 0) {
          $module = basename($doc->fileName);
          $module = substr($module, 0, strrpos($module, '.'));
          $phpdoc = "\n/"."**\n";
          $phpdoc .= "*\n";
          $phpdoc .= "*\n";
          $phpdoc .= "*@module $module\n";
          $phpdoc .= "*@author \n";
          $phpdoc .= "*@version \n";
          $phpdoc .= "*"."/\n";
          
          //Das einf�gen des Dateikommentars is etas anders
          // Einf�gen
          $doc->selstart = $linestart+strlen($line)+1;
          $doc->sellength = 0;
          $doc->seltext = $phpdoc;
      
          // Cursor in erste Zeile r�cken
          $doc->selstart = $linestart+strlen($line)+8;
          $doc->sellength = 0;
          return;
        }
    }

    // Einr�ckung
    $indent = getLineIndent($line);
    $it = str_repeat (" ", $indent);
    $pt = explode("\n", $phpdoc);
    $phpdoc = "";
    foreach ($pt as $ptl) {
      $ptl = $it.$ptl."\n";
      $phpdoc .= $ptl;
    }
    $phpdoc = rtrim($phpdoc)."\n";

    // Einf�gen
    $doc->selstart = $linestart+1;
    $doc->sellength = 0;
    $doc->seltext = $phpdoc;
    $doc->sellength = 0;

    // Cursor in erste Zeile r�cken
    $doc->selstart = $linestart+(2*$indent)+7;
    $doc->sellength = 0;
  }
}

?>