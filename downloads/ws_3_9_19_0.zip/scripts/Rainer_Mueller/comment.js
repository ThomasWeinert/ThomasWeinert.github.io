/**
 * comment.js
 * Create comments around the selected text or remove it.
 *
 * @version 0.2
 * @author Rainer M�ller <mueller_rainer at gmx.de>
 * 
 * This scripts creates comment tags around the actual selected text.
 * It uses the following comments depending on the file extension:
 *
 * TODO: support for single-line comments
**/
 
  var comments = new Array()
  
  //     extension                start     end     single-line(not implemented yet)
  comments['css']     =  new Array('/*',   '*/',     ''           );
  comments['html']    =  new Array('<!--', '//-->',  ''           );
  comments['htm']     =  new Array('<!--', '//-->',  ''           );
  comments['java']    =  new Array('/*',   '*/',     '//'         );
  comments['js']      =  new Array('/*',   '*/',     '//'         );
  comments['php']     =  new Array('/*',   '*/',     '//'         );
  comments['tpl']     =  new Array('{*',   '*}',     ''           );     //Smarty Syntax
  //unknown extensions
  comments['*']       =  new Array('/*',   '*/',     '//');


/* --- BEGIN of functions --- */

function trim(s) 
{
  // remove leading spaces
  while ((s.substring(0,1) == ' '))
  {
    s = s.substring(1,s.length);
  }

  // remove trailing spaces
  while ((s.substring(s.length-1,s.length) == ' '))
  {
    s = s.substring(0,s.length-1);
  }
  return s;
}

function comment_add(str, ext) {
  var seltext = str;
  if (typeof comments[ext] == "undefined") {
    ext = "";
    if (app.messageDlg(4, "Extension not supported or unknown...\nBut you can add it to the script yourself and/or mail it to me, so it will be there in next release!\n\nUse standard comments /* and */?") == 6) {
      ext = "*";
    }
  }
  if (ext != "") {
    /* use single-line, if there is no line break in selected text
    if (seltext.indexOf("\n")   > 0 || 
        seltext.indexOf("\r\n") > 0 || 
        seltext.indexOf("\r")   > 0 || 
        comments[ext][2] == '') {
      
    } else {
      // select the whole line and set the single-line comment at beginning
    }*/
    // use multi line comment as workaround for now
    seltext = comments[ext][0] + " " + str + " " + comments[ext][1];
  }
  return seltext;
}

function comment_remove(str, ext) {
  var seltext = str;
  if (typeof comments[ext] == "undefined") {
    ext = "";
    if (app.messageDlg(4, "Extension not supported or unknown...\nBut you can add it to the script yourself and/or mail it to me, so it will be there in next release!\n\nUse standard comments /* and */?") == 6) {
      ext = "*";
    }
  }
  if (ext != "") {
   /* 
    //use single-line, if there is no line break in selected text
    if (seltext.indexOf("\n")   > 0 || 
        seltext.indexOf("\r")   > 0 || 
        seltext.indexOf("\r\n") > 0 || 
        comments[ext][2] == '') {
      
    } else {
      //select the whole line and set the single-line comment at beginning
    }
   */ // use multi line comment as workaround for now
   
    seltext = trim(str.substr(comments[ext][0].length, str.length - comments[ext][0].length - comments[ext][1].length));
  }
  return seltext;
}

function is_comment(seltext, ext) {
  if (typeof comments[ext] == "undefined") {
    ext = "";
    if (app.messageDlg(4, "Extension not supported or unknown...\nBut you can add it to the script yourself and/or mail it to me, so it will be there in next release!\n\nUse standard comments /* and */?") == 6) {
      ext = "*";
    }
  }
  if (ext != "") {
    if (seltext.substr(0, comments[ext][0].length) == comments[ext][0] && 
        seltext.substr(seltext.length - comments[ext][1].length) == comments[ext][1]) {
      return true;    
    } else {
      return false;
    }
  }
}

/* --- END of functions --- */

/* --- BEGIN of main --- */

var app = application;
var doc = app.document;

if(doc && doc.text != "") {
  // get the file extension
  var ext = "";
  if(doc.fileName != "") {
    ext = doc.fileName;
    if(ext.lastIndexOf("\\") > -1) {
      ext = ext.substr(ext.lastIndexOf("\\") + 1, ext.length);
      if(ext.lastIndexOf(".") > -1) {
        ext = ext.substr(ext.lastIndexOf("."), ext.length);
      }
    }
    if (ext.substr(0,1) == ".") {
      ext = ext.substr(1)
    }
		
		
		//trim line breaks at beginning/end and save them
		  var strtext = doc.seltext;
		  var trim_before = '';
		  var trim_after  = '';
		  //trim before
		  while (strtext.substr(0,1) == "\n") {
		    strtext = strtext.substr(1);
		    trim_before += "\n";
		      app.showMessage("trimmed before");
		  } 
		  while (strtext.substr(0,1) == "\r") {
		    strtext = strtext.substr(1);
		    trim_before += "\r";
		        app.showMessage("trimmed before");
		  }
		  while (strtext.substr(0,2) == "\r\n") {
		    strtext = strtext.substr(2);
		    trim_before += "\r\n";
		        app.showMessage("trimmed before");
		  }
		  //trim after
		  while (strtext.substr(strtext.length - 1) == "\n") {
		    strtext = strtext.substr(0, strtext.length - 1);
		    trim_after += "\n";
		      app.showMessage("trimmed after");
		  } 
		  while (strtext.substr(strtext.length - 1) == "\r") {
		    strtext = strtext.substr(0, strtext.length - 1);
		    trim_after += "\r";
		      app.showMessage("trimmed after");
		  }
		  while (strtext.substr(strtext.length - 2) == "\r\n") {
		    strtext = strtext.substr(0, strtext.length - 1);
		    trim_after += "\r\n";
		      app.showMessage("trimmed after");
		  }
		    
		  //add comment or remove comment?
		  if (is_comment(doc.seltext, ext) == true) { 
		    //remove comment
		    doc.seltext = trim_before + comment_remove(strtext, ext) + trim_after;
		  } else {
		    //add comment
		    doc.seltext = trim_before + comment_add(strtext, ext) + trim_after;
		    // doc.sellength = 0;
		  }
  } else {
    app.showMessage("Sorry, but this script cannot be used before saving because it needs the file extension!");
  }
}

/* --- END of main --- */