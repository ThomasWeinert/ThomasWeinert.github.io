<?
// Start Template Cut - Diese Zeilen unde den Code dazwischen nicht ver�ndern
/**
* Funktion gibt den Inhalt von $Scriptfile zur�ck unter Nichtbeachtung
* von Zeilen, die mit "// Start Template Cut" oder "// End Template Cut"
* beginnen oder zwischen diesen Beiden liegen.
*
* @author  Jan H�ffelmann <jan@microbitch.biz>
*
* @param String $ScriptFile
* 
* @return String geparster Dateiinhalt
*/
function GetFormTemplate($ScriptFile)
  {
  $retw = "";
  $abuf = array();
  $inc  = true;
  if ($buf = @file($ScriptFile))
    {
    foreach ($buf as $line)
      {
      if ($inc)
        {
        if (preg_match("/^[\\s]*\\/\\/ Start Template Cut/",$line))
          {
          $inc = false;
          }
        else
          {
          $abuf[count($abuf)] = preg_replace("/^(.*)[\\s\\n\\r]*\$/","\$1",$line);
          }
        }
      else
        {
        if (preg_match("/^[\\s]*\\/\\/ End Template Cut/",$line))
          {
          $inc = true;
          }
        }
      }
    }
  return rtrim(implode("\n",$abuf));
  }
// End Template Cut - Diese Zeilen unde den Code dazwischen nicht ver�ndern
/**
* Name Der Dialog-Applikation
*/
define("AppName","KixForms Dialog");
/**
* Ein einfaches Formular mit KixForms und ActivePHP
* Soll als Beispiel dienen, um dem WeaverSlave-Benutzer
* die Benutzung der KixForms.dll n�her zu bringen
* Die Dll kann von http://kixforms.org frei heruntergeladen werden.
* Einfach nach System32 kopieren und per regsrv32 kixforms.dll registrieren.
* 
* @version 1.0
*/
class KixForm
  {
  /**
  * 
  * @var Object Das Application Objekt von WeaverSlave
  */
  var $Application; 
  /**
  * 
  * @var Com Das Formular
  */
  var $Form;
  /**
  * 
  * @var Com Ok Button
  */
  var $ButtonOk; 
  /**
  * 
  * @var Com Cancel Button
  */
  var $ButtonCancel; 
  /**
  * 
  * @var Integer Padding der Formularelemente (global)
  */
  var $ControlPadding = 2; 
  /**
  * 
  * @var Com TextBox
  */
  var $Editor; 
  /**
  * 
  * @var Com Handle zum System Objekt von KixForms
  */
  var $System; 
  /**
  * 
  * @var Mixed Wert, der von der Show Funktion zur�ckgegeben wird
  */
  var $ReturnValue;   
  
  /**
  * 
  * @var Integer Schaltfl�chenbreite 
  */
  var $bWidth  = 80;
  /**
  * 
  * @var Integer Schaltfl�chenh�he 
  */
  var $bHeight = 24;
  /**
  * 
  * @var Integer  Formularh�he
  */
  var $fHeight = 240; # 
  /**
  * 
  * @var Integer Formularbreite
  */
  var $fWidth  = 320;
  
  /**
  * Klassen Konstruktor
  *
  * @return Object
  */
  function KixForm()
    {
    global $application;
    
    $this->System = @new com("KixTart.System");
    if (empty($this->System))  {return false;}
    
    if (!empty($application))
      {
      if (!preg_match("/^weaverslave/",strtolower(@$application->EditorName())))
        {
        $this->NoWsErr();
        return false;
        }
      else
        {
        $this->Form = @$this->System->Form($this->Application->Handle);
        if (empty($this->Form))  {return false;}
        $this->Application = $application;
        $this->Form->Text  = AppName." for ".$this->Application->EditorName();
        $this->Form->Icon  = $this->Application->ExeName();
        }
      }
    else
      {
      $this->NoWsErr();
      return false;
      }    
    
    /** Formular einrichten */
    $this->Form->Height = $this->fHeight;
    $this->Form->Width  = $this->fWidth;
    
    /** Ok-Button definieren */
    $this->ButtonOk          = $this->Form->Controls->Button("&Ok");
    $this->ButtonOk->Width   = $this->bWidth;
    $this->ButtonOk->Height  = $this->bHeight;
    $this->ButtonOk->Top     = $this->Form->ClientHeight - $this->bHeight - $this->ControlPadding;
    $this->ButtonOk->Left    = $this->Form->ClientWidth - $this->bWidth - $this->ControlPadding;
    $this->ButtonOk->OnClick = '$this->ButtonOk_OnClick();';
    $this->ButtonOk->Anchor  = 10;
    
    /** Cancel-Button definieren */
    $this->ButtonCancel          = $this->Form->Controls->Button("&Cancel");
    $this->ButtonCancel->Width   = $this->bWidth;
    $this->ButtonCancel->Height  = $this->bHeight;
    $this->ButtonCancel->Top     = $this->ButtonOk->Top;
    $this->ButtonCancel->Left    = $this->ButtonOk->Left - $this->ControlPadding - $this->bWidth;
    $this->ButtonCancel->OnClick = '$this->ButtonCancel_OnClick();';
    $this->ButtonCancel->Anchor  = 10;
    
    $this->Editor                = $this->Form->Controls->TextBox();
    $this->Editor->Multiline     = True;
    $this->Editor->Left          = $this->ControlPadding;
    $this->Editor->Top           = $this->ControlPadding;
    $this->Editor->Width         = $this->Form->ClientWidth - (2 * $this->ControlPadding);
    $this->Editor->Height        = $this->Form->ClientHeight - (3 * $this->ControlPadding) - $this->bHeight;
    $this->Editor->FontName      = "Courier New";
    $this->Editor->FontSize      = 12;
    $this->Editor->Text          = $this->Form->Text;
    $this->Editor->ScrollBars    = 3;
    $this->Editor->WordWrap      = false;
    $this->Form->FormBorderStyle = 4;
    $this->ButtonOk->Left        = $this->ButtonOk->Left - 10;
    $this->ButtonCancel->Left    = $this->ButtonCancel->Left - 10;
    $this->Editor->Anchor        = 15;
    // Start Template Cut - Diese Zeilen unde den Code dazwischen
    $this->Form->Width  = 800;
    $this->Form->Height = 600;
    // End Template Cut - Diese Zeilen unde den Code dazwischen
    }
  /**
  * Anzeigefunktion des Formulares
  *
  * @return Boolean
  */
  function Show()
    {
    if (!empty($this->Application))
      {
      // Start Template Cut - Diese Zeilen unde den Code dazwischen nicht ver�ndern
      $this->Editor->Text = GetFormTemplate($this->Application->ScriptFile());
      // End Template Cut - Diese Zeilen unde den Code dazwischen nicht ver�ndern
      $this->Form->FormStartPosition = 4;
      $this->Form->Show();
      while ($this->Form->Visible)
        {
        eval($this->Form->DoEvents());
        }
      }
      return $this->ReturnValue;
    }
  /**
  * Der OnClick-Handler des Ok Buttons
  *
  * @return void
  */
  function ButtonOk_OnClick()
    {
    $this->Form->Hide();
    if ($this->Application->CreateDocument(".php"))
      {
      $doc = $this->Application->Document();
      $doc->Text = $this->Editor->Text;
      $this->ReturnValue = true;
      }
    else
      {
      $this->ReturnValue = false;
      }
    }
  /**
  * Der OnClick-Handler des Cancel Buttons
  *
  * @return void
  */
  function ButtonCancel_OnClick()
    {
    $this->Form->Hide();
    $this->ReturnValue = false;
    }
  /**
  * Funktion zur Anzeige von Meldungen
  *
  * @param String$Msg
  * 
  * @return void
  */
  function MsgBox($Msg,$flags = 0)
    {
    if (empty($this->Form))
      {
      $frm = @new com("WScript.Shell");
      $frm.PopUp($Msg,10,AppName,$flags);
      }
    else
      {
      $mBox = $this->Form->MessageBox();
      $mBox->Show($Msg,AppName,$flags,1);
      }
    }
  /**
  * Spezialkommentar, der eigentlich nur wegen Textf�lle in eine eigene
  * Funktion gewandert ist
  *
  * @return void
  */
  function NoWsErr()
    {
    $this->MsgBox("Dieses Script funktioniert nur unter WeaverSlave.\n".
                  "WeaverSlave ist ein frei verf�gbarer Programmier-Editor,\n".
                  "der von der Website http://www.weaverslave.ws heruntergeladen\n".
                  "werden kann.");
    $this->Application = false;
    }
  }
$Form = new KixForm();
$Form->Show();
?>
