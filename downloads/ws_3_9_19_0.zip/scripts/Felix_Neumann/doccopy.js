////////
//  Document copy
//  Duplicates the active document to a new window.
//
//  (c) Felix Neumann 2004
//  http://www.feeprogramms.de
//  support@feeprogramms.de
////
   
var app = application;
var doc = app.document;

if(doc && doc.text != "") {
							
	// get the file extension
	var ext = "";
	if(doc.fileName != "") {
		ext = doc.fileName;
		if(ext.lastIndexOf("\\") > -1) {
			ext = ext.substr(ext.lastIndexOf("\\") + 1, ext.length);
			if(ext.lastIndexOf(".") > -1) {
				ext = ext.substr(ext.lastIndexOf("."), ext.length);
			}
		}
	}
  
	// Duplicate the document
	var s = doc.text;
	app.createDocument(ext);
	doc.text = s;		   

}