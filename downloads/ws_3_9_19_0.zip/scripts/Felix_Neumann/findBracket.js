////////
//  find bracket
//  Searches the associated bracket. For example, move your cursor over "(",
//  and the script will select the associated ")".
//  Works with (), [] and {}.
//
//  (c) Felix Neumann 2004
//  http://www.feeprogramms.de
//  support@feeprogramms.de
////

if(application && application.document && application.document.text.length > 1) {

	var app = application;
	var doc = application.document;
	var text = application.document.text;
	
  // Language
  	if(app.editorLanguage == "de") {
		var lng_move_to_bracket = "Bewegen Sie Ihren Cursor zu einer Klammer, um ihr Gegenst�ck anzuzeigen.";
		var lng_no_bracket_found = "Es konnte kein Gegenst�ck zur angegebenen Klammer gefunden werden.";
	} else {
		var lng_move_to_bracket = "Move the cursor to an opening/closing bracket to show the associated closing/opening bracket.";
		var lng_no_bracket_found = "I couldn't find an associated bracket.";
	}
	
  // Is the cursor above a bracket?
	var c = text.substr(doc.selstart, 1);
	if( c != "(" && c != ")" &&
		c != "[" && c != "]" &&
		c != "{" && c != "}" ) {
		app.showMessage(lng_move_to_bracket);	
	} else {
	
	
//// SEARCH FUNCTIONS //////////////////////////////////////////////////////////////////////
		// Searches forward
		function strSearchFwd(needle, haystack, startIndex) {
			var level = 0;
			var found = false;
			var i = startIndex;
			var q_big = false;		// in ""?
			var q_small = false;	// in ''?
			
			while(i < haystack.length) {
				i++;
				c = text.substr(i, 1);
		
				if(c == "\"" && !q_small) {
				  // no Backslashes
				    var i2 = i - 1;
					var isValid = true;
					while(i2 > 0 && text.substr(i2, 1) == "\\") {
						isValid = !isValid;
						i2--;
					}
					if(isValid) q_big = !q_big;
				}
				if(c == "'" && !q_big) {
				  // no backslashes
				    var i2 = i - 1;
					var isValid = true;
					while(i2 > 0 && text.substr(i2, 1) == "\\") {
						isValid = !isValid;
						i2--;
					}
					if(isValid) q_small = !q_small;
				}
				if(q_big || q_small) continue;
				
				if(level == 0 && c == needle) {
					return i;
				}
		
				if(c == "(" || c == "[" || c == "{") level++;
				if(c == ")" || c == "]" || c == "}") level--;
			}
			i = -1;
		}
		
		// Searches backward
		function strSearchBack(needle, haystack, startIndex) {
			var level = 0;
			var found = false;
			var i = startIndex;
			var q_big = false;		// in ""?
			var q_small = false;	// in ''?
			
			while(i > 0) {
				i--;
				c = text.substr(i, 1);
		
				if(c == "\"" && !q_small) {
				  // no Backslashes
				    var i2 = i - 1;
					var isValid = true;
					while(i2 > 0 && text.substr(i2, 1) == "\\") {
						isValid = !isValid;
						i2--;
					}
					if(isValid) q_big = !q_big;
				}
				if(c == "'" && !q_big) {
				  // no backslashes
				    var i2 = i - 1;
					var isValid = true;
					while(i2 > 0 && text.substr(i2, 1) == "\\") {
						isValid = !isValid;
						i2--;
					}
					if(isValid) q_small = !q_small;
				}
				if(q_big || q_small) continue;
				
				if(level == 0 && c == needle) {
					return i;
				}
		
				if(c == "(" || c == "[" || c == "{") level--;
				if(c == ")" || c == "]" || c == "}") level++;
			}
			i = -1;
		}
		
	  // Search the next bracket.
		if(c == "(") var i = strSearchFwd(")", text, doc.selstart); else
		if(c == "[") var i = strSearchFwd("]", text, doc.selstart); else
		if(c == "{") var i = strSearchFwd("}", text, doc.selstart); else
		if(c == ")") var i = strSearchBack("(", text, doc.selstart); else
		if(c == "]") var i = strSearchBack("[", text, doc.selstart); else
		if(c == "}") var i = strSearchBack("{", text, doc.selstart);
		
	  // Is there any associated bracket?
		if(i > -1) {
			doc.selstart = i;
			doc.sellength = 1;
		} else {
			app.showMessage(lng_no_bracket_found);
		}

	} // Is there any bracket at the cursorPos?

} // Is the Weaverslave opened?