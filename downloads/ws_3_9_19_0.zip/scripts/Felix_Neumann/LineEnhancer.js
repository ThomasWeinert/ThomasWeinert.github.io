////////
//  Line Expander
//  Set an user-defined text before and / or after every line.
//
//  (c) Felix Neumann 2004
//  http://www.feeprogramms.de
//  support@feeprogramms.de
////

var app = application;
var doc = app.document;

if(doc) {

if(app.editorLanguage == "de") {
	var lng_enhance_lines = "Zeilen erweitern";
	var lng_enhance_prefix = "Was soll vor jede Zeile gestellt werden?";
	var lng_enhance_suffix = "Was soll nach jede Zeile gestellt werden?";
} else {
	var lng_enhance_lines = "Expand lines";
	var lng_enhance_prefix = "Text to set before every line:";
	var lng_enhance_suffix = "Text to set after every line:";
}

var prefix = app.inputDlg(lng_enhance_lines, lng_enhance_prefix, "");
var suffix = app.inputDlg(lng_enhance_lines, lng_enhance_suffix, "");

if((prefix != "" || suffix != "") && app.document.sellength > 0) {

	var txt = doc.selText;
	txt = txt.replace(/\r/, "");
	var lines = txt.split("\n");

	for(x = 0; x < lines.length; x++) lines[x] = prefix + lines[x] + suffix;

	doc.selText = lines.join("\n");
}

}
