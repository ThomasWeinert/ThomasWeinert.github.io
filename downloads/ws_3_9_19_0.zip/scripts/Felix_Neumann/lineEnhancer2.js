////////
//  Line Extender v2.1
//  Set an user-defined text before and / or after every line.
//  Now supports an graphical interface, when KiXforms is installed -
//  otherwise, the standard Weaverslave dialog boxes are used.
// 	Additionally, the script now includes XML support for saving options.
//
//  See http://www.kixforms.org for more information about KiXforms.
//  See http://www.microsoft.com for more information about the XML-
//  interface.
//
//  (c) Felix Neumann 2004
//  http://www.feeprogramms.de
//  support@feeprogramms.de
////



//// XML ///////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
					  
// Load XML-support.
var xmlSupport = true;					// Is xmlSupport enabled?
var file;								// Filename of the XML-file.
var rootNodeName = "LineEnhancer";		// Name of the root node in the XML-file.

// Try to load the ActiveX-Object.
try { var dom = new ActiveXObject("Microsoft.XMLDOM"); }
catch (err_no) { xmlSupport = false; }

if(xmlSupport) {
	// Create the file name
	file = application.scriptFile();
	file = file.substring(0, file.lastIndexOf(".")) + ".xml";
	// Load the file. If it does not exist, no error will occur. Instead,
	// it will be created later (when the options are saved).
	dom.load(file);
}
  

// Several functions & procedures.
// Hint:
//   loadOption & saveOption are the functions really needed, they also
//   check, if there is XML support.

// Returns the root node of the document.
// out: IXMLDOMNode
function getRootNode() {
	return dom.selectSingleNode("//" + rootNodeName);
}

// Checks if a node exists.
// in: parentNode (IXMLDOMElement), nodeName (string)
// out: bool
function nodeExists(parentNode, nodeName) {
	var oNodes = parentNode.getElementsByTagName(nodeName);
	return oNodes.length > 0;
}

// Creates an element and checks if it is created propably.
// in: parentNode (IXMLDOMNode, if createAsRoot = false), nodeName (string),
//     createAsRoot (bool)
// out: bool
function createElement(parentNode, nodeName, createAsRoot) {
	var newElement = dom.createElement(nodeName);
	if(createAsRoot) {
		dom.documentElement = newElement;
		return dom.documentElement != null;
	} else {
		parentNode.appendChild(newElement);
		return parentNode.selectSingleNode(nodeName) != null;
	}
}

// Writes the text content for an element.
// in: parentNode (IXMLDOMNode), nodeName (string), content (string)
// out: bool
function setTextContent(parentNode, nodeName, content) {
  // Is "nodeName" valid?
	if(!nodeExists(parentNode, nodeName)) return false;

  // Get the node as variable and set its text.
	var oNode = parentNode.selectSingleNode(nodeName);
	if(oNode != null) {
		oNode.text = content;
		return true;
	} else return false;
}	  

// Reads the text content for an element.
// in: parentNode (IXMLDOMNode), nodeName (string), defaultValue (string)
// out: string
function getTextContent(parentNode, nodeName, defaultValue) {
  // Is "nodeName" valid?
	if(!nodeExists(parentNode, nodeName)) return defaultValue;
		
  // Get the node as variable and set its text.
	var oNode = parentNode.selectSingleNode(nodeName);
	if(oNode == null) return defaultValue; else	return oNode.text;
}	  


// Saves an option. Many functions from above are used here.
// in: optCategorie (string, may be empty), optName (string), optValue (string)
// out: bool
function saveOption(optCategorie, optName, optValue) {
	if(!xmlSupport) return false;
  // May be we have to create the nodes.
    // Root node
	if(!nodeExists(dom, rootNodeName)) {
		if(!createElement(dom, rootNodeName, true)) return false;
	}
	var root = getRootNode(); 
	// Categorie node
	if(optCategorie != "") {
		if(!nodeExists(root, optCategorie)) {
			if(!createElement(root, optCategorie, false)) return false;
		}
		var oCatNode = root.selectSingleNode(optCategorie);
	} else {
		var oCatNode = root;
	}
	// Property's node
	if(!nodeExists(oCatNode, optName)) {
		if(!createElement(oCatNode, optName, false)) return false;
	}
  // Set content
	return setTextContent(oCatNode, optName, optValue);
}

// Loads an option. Many functions from above are used here. 
// in: optCategorie (string, may be empty), optName (string), optDefault (string)
// out: string
function loadOption(optCategorie, optName, optDefault) {
	if(!xmlSupport) return optDefault;
  // Maybe the nodes don't exist...
    // Root node
	if(!nodeExists(dom, rootNodeName)) return optDefault;
	var root = getRootNode(); 
	// Categorie node
	if(optCategorie != "") {
		if(!nodeExists(root, optCategorie)) return optDefault;
		var oCatNode = root.selectSingleNode(optCategorie);
	} else {
		var oCatNode = root;
	}
	// Property's node
	if(!nodeExists(oCatNode, optName)) return optDefault;
  // Set content
	return getTextContent(oCatNode, optName, optDefault);
}



//// WINDOW CODE ///////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

if(application && application.document) {
	var app = application;
	var doc = app.document;
	
	// Language definitions
	// The vocabulary of the application
	if(app.editorLanguage == "de") {
		var lng_caption = "Zeilen erweitern";
		var lng_enhance_prefix = "Vor jede Zeile stellen:";
		var lng_enhance_suffix = "Nach jede Zeile stellen:";
		var lng_intro = "Hier k�nnen Sie beliebigen Text vor und / oder nach jede markierte Zeile setzen.";
		var lng_msg_no_lines_selected = "Es wurde nichts markiert. Stellen Sie sicher, dass Sie die Zeilen, die Sie vom Skript bearbeiten lassen wollen, markiert haben.";
		var lng_msg_no_input = "Sie m�ssen mindestens eines der beiden Textfelder ausf�llen, um die Aktion durchzuf�hren.";
	} else {
		var lng_caption = "Extend lines";
		var lng_enhance_prefix = "Text to set before every line:";
		var lng_enhance_suffix = "Text to set after every line:";
		var lng_intro = "With this tool, you can set any text you want in front of or after every line.";
		var lng_msg_no_lines_selected = "No text is selected. Please select those lines you want to extend.";
		var lng_msg_no_input = "To run the script you have to enter text in at least one of both input fields.";
	}
	
	// Load last used values out of the XML file.
	var pre_default = loadOption("lastUsed", "prefix", "");
	var suf_default = loadOption("lastUsed", "suffix", "");	
	
	// PRE-CHECK 2
	if(doc.sellength > 0) {
	
		// This is the main part of the program.
		// Here, the extention of the lines takes place.
		function doExtend(prefix, suffix) {		
			var txt = doc.selText;
			txt = txt.replace(/\r/, "");
			var lines = txt.split("\n");
	
			for(x = 0; x < lines.length; x++) lines[x] = prefix + lines[x] + suffix;
	
			doc.selText = lines.join("\n");
		}
	
	    // Try: against no-KiXforms-installed
		try {
		  // Initialize the KiXforms application
			var system = new ActiveXObject("Kixtart.System");	

//// EVENTS /////////////////////////////////////////////////////////////////////////////
			function btnOkClick() {
				var prefix = form.PrefixMemo.Text;
				var suffix = form.SuffixMemo.Text;
			  // Save the used values to the XML file.
			  	if(xmlSupport) {
					saveOption("lastUsed", "prefix", prefix);
					saveOption("lastUsed", "suffix", suffix);
				  // Here, the XML-file is created if necessary and written.
					dom.save(file);
				}
				
			  // Execute!
				if(prefix != "" || suffix != "") {
					form.Hide();
					doExtend(prefix, suffix);
				} else {
					msg = system.MessageBox();
					msg.Style = 64;
					msg.Title = lng_caption;
					msg.Show(lng_msg_no_input);
				}
			} 
				 
//// INTERFACE //////////////////////////////////////////////////////////////////////////
			// FORM
			var form = system.Form();
			form.Icon = application.exeName;
			form.MaximizeBox = false;
			form.ClientSize = system.Size(300,310);
			form.BorderStyle = 1;
			form.Font = system.Font("Tahoma", 8.5);
			form.Text = lng_caption;
			
			// INTROLABEL
			form.IntroLabel = form.Controls.Label();
			form.IntroLabel.Size = system.Size(275, 30);
			form.IntroLabel.Center();
			form.IntroLabel.Top = 10;
			form.IntroLabel.Text = lng_intro;
			
			// IN FRONT OF THE LINES
			form.PrefixLabel = form.Controls.Label();
			form.PrefixLabel.Size = system.Size(275, 15);
			form.PrefixLabel.Center();
			form.PrefixLabel.Top = 50;
			form.PrefixLabel.Text = lng_enhance_prefix;
			
			form.PrefixMemo = form.Controls.TextBox();
			form.PrefixMemo.Size = system.Size(275, 80);
			form.PrefixMemo.Center();
			form.PrefixMemo.Top = 70;
			form.PrefixMemo.Font = system.Font("Courier New", 8.5);
			form.PrefixMemo.Multiline = true;
			form.PrefixMemo.AcceptsTab = true;
			form.PrefixMemo.Text = pre_default;
			
			// BEHIND THE LINES
			form.SuffixLabel = form.Controls.Label();
			form.SuffixLabel.Size = system.Size(275, 15);
			form.SuffixLabel.Center();
			form.SuffixLabel.Top = 165;
			form.SuffixLabel.Text = lng_enhance_suffix;
			
			form.SuffixMemo = form.Controls.TextBox();
			form.SuffixMemo.Size = system.Size(275, 80);
			form.SuffixMemo.Center();
			form.SuffixMemo.Top = 185;
			form.SuffixMemo.Font = system.Font("Courier New", 8.5);
			form.SuffixMemo.Multiline = true;
			form.SuffixMemo.AcceptsTab = true;
			form.SuffixMemo.Text = suf_default;
			
			// ABOUT
			form.AboutLabel = form.Controls.Label();
			form.AboutLabel.Size = system.Size(150, 15);
			form.AboutLabel.Left = form.SuffixLabel.Left;
			form.AboutLabel.Top = 285;
			form.AboutLabel.Text = "(c) Felix Neumann 2004";
			
			// OK
			form.OkButton = form.Controls.Button();
			form.OkButton.Size = system.Size(75,25);
			form.OkButton.Text = "OK";
			form.OkButton.OnClick = "btnOkClick()";
			form.OkButton.Center();
			form.OkButton.Top = 280;
			form.OkButton.Left = form.Width - form.OkButton.Width - form.AboutLabel.Left;
			
			
//// ACTIONS ////////////////////////////////////////////////////////////////////////////
			form.Center()
			form.show();
			
			while (form.visible) {
				eval(form.doEvents());
			}
			
		}
		
		
//// NON-KiX-PART ///////////////////////////////////////////////////////////////////////
  // This part is executed, when there is no KiXforms installed.
		catch(err_no) {
			var prefix = app.inputDlg(lng_caption, lng_enhance_prefix, pre_default);
			var suffix = app.inputDlg(lng_caption, lng_enhance_suffix, suf_default);			
			
			if(prefix != "" || suffix != "") {
			  // Save the used values to the XML file.
			  	if(xmlSupport) {
					saveOption("lastUsed", "prefix", prefix);
					saveOption("lastUsed", "suffix", suffix);
				  // Here, the XML-file is created if necessary and written.
					dom.save(file);
				}
			  // Executes.
				doExtend(prefix, suffix);
			}	
		}
	
//// SOME ERRORS AND WARNINGS ///////////////////////////////////////////////////////////
	} else {
		if(!doc.sellength) app.showMessage(lng_msg_no_lines_selected);
	}

}

