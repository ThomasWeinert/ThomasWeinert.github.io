////////
//  Line Enhancer XML
//  Set an user-defined text before and / or after every line.
//  Includes XML support for saving options.
//
//  (c) Felix Neumann 2004
//  http://www.feeprogramms.de
//  support@feeprogramms.de
//
//  You may use the XML-features shown in this script in your own scripts.
//  Please note my copyright then.
////



//// XML ///////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
					  
// Load XML-support.
var xmlSupport = true;					// Is xmlSupport enabled?
var file;								// Filename of the XML-file.
const rootNodeName = "LineEnhancer";	// Name of the root node in the XML-file.

// Try to load the ActiveX-Object.
try { var dom = new ActiveXObject("Microsoft.XMLDOM"); }
catch (err_no) { xmlSupport = false; }

if(xmlSupport) {
	// Create the file name
	file = application.scriptFile();
	file = file.substring(0, file.lastIndexOf(".")) + ".xml";
	// Load the file. If it does not exist, no error will occur. Instead,
	// it will be created later (when the options are saved).
	dom.load(file);
}
  

// Several functions & procedures.
// Hint:
//   loadOption & saveOption are the functions really needed, they also
//   check, if there is XML support.

// Returns the root node of the document.
// out: IXMLDOMNode
function getRootNode() {
	return dom.selectSingleNode("//LineEnhancer");
}

// Checks if a node exists.
// in: parentNode (IXMLDOMElement), nodeName (string)
// out: bool
function nodeExists(parentNode, nodeName) {
	var oNodes = parentNode.getElementsByTagName(nodeName);
	return oNodes.length > 0;
}

// Creates an element and checks if it is created propably.
// in: parentNode (IXMLDOMNode, if createAsRoot = false), nodeName (string),
//     createAsRoot (bool)
// out: bool
function createElement(parentNode, nodeName, createAsRoot) {
	var newElement = dom.createElement(nodeName);
	if(createAsRoot) {
		dom.documentElement = newElement;
		return dom.documentElement != null;
	} else {
		parentNode.appendChild(newElement);
		return parentNode.selectSingleNode(nodeName) != null;
	}
}

// Writes the text content for an element.
// in: parentNode (IXMLDOMNode), nodeName (string), content (string)
// out: bool
function setTextContent(parentNode, nodeName, content) {
  // Is "nodeName" valid?
	if(!nodeExists(parentNode, nodeName)) return false;

  // Get the node as variable and set its text.
	var oNode = parentNode.selectSingleNode(nodeName);
	if(oNode != null) {
		oNode.text = content;
		return true;
	} else return false;
}	  

// Reads the text content for an element.
// in: parentNode (IXMLDOMNode), nodeName (string), defaultValue (string)
// out: string
function getTextContent(parentNode, nodeName, defaultValue) {
  // Is "nodeName" valid?
	if(!nodeExists(parentNode, nodeName)) return defaultValue;
		
  // Get the node as variable and set its text.
	var oNode = parentNode.selectSingleNode(nodeName);
	if(oNode == null) return defaultValue; else	return oNode.text;
}	  


// Saves an option. Many functions from above are used here.
// in: optCategorie (string, may be empty), optName (string), optValue (string)
// out: bool
function saveOption(optCategorie, optName, optValue) {
	if(!xmlSupport) return false;
  // May be we have to create the nodes.
    // Root node
	if(!nodeExists(dom, "LineEnhancer")) {
		if(!createElement(dom, "LineEnhancer", true)) return false;
	}
	var root = getRootNode(); 
	// Categorie node
	if(optCategorie != "") {
		if(!nodeExists(root, optCategorie)) {
			if(!createElement(root, optCategorie, false)) return false;
		}
		var oCatNode = root.selectSingleNode(optCategorie);
	} else {
		var oCatNode = root;
	}
	// Property's node
	if(!nodeExists(oCatNode, optName)) {
		if(!createElement(oCatNode, optName, false)) return false;
	}
  // Set content
	return setTextContent(oCatNode, optName, optValue);
}

// Loads an option. Many functions from above are used here. 
// in: optCategorie (string, may be empty), optName (string), optDefault (string)
// out: string
function loadOption(optCategorie, optName, optDefault) {
	if(!xmlSupport) return optDefault;
  // Maybe the nodes don't exist...
    // Root node
	if(!nodeExists(dom, "LineEnhancer")) return optDefault;
	var root = getRootNode(); 
	// Categorie node
	if(optCategorie != "") {
		if(!nodeExists(root, optCategorie)) return optDefault;
		var oCatNode = root.selectSingleNode(optCategorie);
	} else {
		var oCatNode = root;
	}
	// Property's node
	if(!nodeExists(oCatNode, optName)) return optDefault;
  // Set content
	return getTextContent(oCatNode, optName, optDefault);
}



//// HEADER ////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

// load Weaverslave's objects
var app = application;
var doc = app.document;

if(doc) {

if(app.editorLanguage == "de") {
	var lng_enhance_lines = "Zeilen erweitern";
	var lng_enhance_prefix = "Was soll vor jede Zeile gestellt werden?";
	var lng_enhance_suffix = "Was soll nach jede Zeile gestellt werden?";
} else {
	var lng_enhance_lines = "Expand lines";
	var lng_enhance_prefix = "Text to set before every line:";
	var lng_enhance_suffix = "Text to set after every line:";
}



//// BODY //////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
														   
// Load last used values out of the XML file.
var pre_default = loadOption("lastUsed", "prefix", "");
var suf_default = loadOption("lastUsed", "suffix", "");

// Open the input dialogs.
var prefix = app.inputDlg(lng_enhance_lines, lng_enhance_prefix, pre_default);
var suffix = app.inputDlg(lng_enhance_lines, lng_enhance_suffix, suf_default);

if((prefix != "" || suffix != "") && app.document.sellength > 0) {
						 
  // Save the used values to the XML file.
  	if(xmlSupport) {
		saveOption("lastUsed", "prefix", prefix);
		saveOption("lastUsed", "suffix", suffix);
	  // Here, the XML-file is created if necessary and written.
		dom.save(file);
	}

  // Convert the text into an array.
	var txt = doc.selText;
	txt = txt.replace(/\r/, "");
	var lines = txt.split("\n");

  // Edit the lines.
	for(x = 0; x < lines.length; x++) lines[x] = prefix + lines[x] + suffix;
					
  // Merge the lines.
	doc.selText = lines.join("\n");
}

}

