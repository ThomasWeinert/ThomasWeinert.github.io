////////
//  TagsToLowercase
//  Sets the whole text which is in "<" and ">" (excepting text in " and ') to lowercase.
//
//  (c) Felix Neumann 2004
//  http://www.feeprogramms.de
//  support@feeprogramms.de
////
        
var app = application;
var doc = app.document;

if(doc) {

  // Input
  var txt = doc.text;
  // Output
  var txtOut, c; txtOut = c = "";
  
  // vars to save, where we are
  var in_big_quotmarks = false;
  var in_small_quotmarks = false;
  var in_tag = false; 
     
  
  // Go thru the source!
  for(x = 0; x <= txt.length; x++) {
    // Put old char to txtOut
      txtOut += c;
        
    // Handle the next position
    c = txt.charAt(x);
    
    // Tag opens?
    if(!in_big_quotmarks && !in_small_quotmarks && !in_tag) {	
      if( (c == "<") && (txt.charAt(x + 1) != "!")) in_tag = true;
      continue;
    }
    // Tag closes?
    if(!in_big_quotmarks && !in_small_quotmarks && in_tag && c == ">") {
      in_tag = false;
      continue;
    }
    // Double quotes?
    if(in_tag && !in_small_quotmarks) {
      if(c == "\"") {
        in_big_quotmarks = !in_big_quotmarks;
        continue;
      }
    }
    // Single quotes?
    if(in_tag && !in_big_quotmarks) {
      if(c == "'") {
        in_small_quotmarks = !in_small_quotmarks;
        continue;
      }
    }
                 
    // To lower case
    if(!in_big_quotmarks && !in_small_quotmarks)
    c = c.toLowerCase();
  }
  
  // append the last char
  txtOut += c;
  // print out the text.
  application.document.text = txtOut;

}
