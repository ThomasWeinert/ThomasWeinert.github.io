//
// copyright 2004 by Thomas Weinert <thomas@weaverslave.ws>
//
// based on an ActivePHP version by
//   Jan Wildeboer <jan.wildeboer@gmx.de>
//   Thomas Weinert <thomas@weaverslave.ws>
//   Andreas Habeck <andreas.habeck@stud.uni-karlsruhe.de>
//
// Put in the Public Domain by the Authors
//

var TYPE_FUNCTION =  1;
var TYPE_VAR =  2;
var TYPE_CLASS =  3;
var TYPE_DEFINE =  4;
var TYPE_INCLUDE =  5;
var TYPE_FILE =  20;

var INSERT_CVS_VERSION = true;
var CVS_USER = application.username;
var AUTHOR = "Thomas Weinert <thomas@weaverslave.ws>";

function rtrim(str)
{
  return str.replace(/\s+$/, '');
}

function ltrim(str)
{
  return str.replace(/^\s+/, '');
}

function trim(str) 
{
  return ltrim(rtrim(str));
}

function getLineType(sLine)
{
  if (sLine == '') {
    application.showMessage('Line empty');
    return false;
  }
  if (sLine.match(/^\s*((public|private|protected)\s+)?((static|abstract)\s+)?function.*/i)) {
    return TYPE_FUNCTION;
  } else if (sLine.match(/^\s*(var|public|private|protected)\s+/i)) {
    return TYPE_VAR;
  } else if (sLine.match(/^\s*class/i)) {
    return TYPE_CLASS;
  } else if (sLine.match(/^\s*define\s*\(/i)) {
    return TYPE_DEFINE;
  } else if (sLine.match(/^\s*(include|require)(_once)?\s*/i)) {
    return TYPE_INCLUDE;
  } else if (sLine.match(/^<\?php/i)) {
    return TYPE_FILE;
  }
  return false;
}

function getFunctionDetails(sLine)
{
  var regs = sLine.match(/^\s*((public|private|protected)\s+)?((static|abstract)\s+)?function\s+&{0,1}(\w+)\s*\(([^)]*)(.*)/i);
  if (regs) {
    var result = new Array();
    if (regs[2] == 'private' || regs[2] == 'protected') {
      result['access'] = regs[2];
    } else {
      result['access'] = 'public';
    }
    result['functionname'] = regs[5];
    result['params'] = regs[6]; 
    return result;
  } else {
    application.showMessage('Could not get function params.');
    return false;
  }
}

function getVarDetails(sLine)
{
  var regs = sLine.match(/^\s*(var|public|private|protected)\s+\$(\w[\w\d]*)(\s*=\s*([\'\"\d]|array|null))?/i);
  if (regs) {
    var sValue = regs[4].toLowerCase();
    sValue = sValue.replace(/^\w+(.*)\w+$/g, '$1');
    var sVarType = '';
    if (sValue == '') {
      sVarType = '';
    } else if (sValue.charAt(0) == '"' || sValue.charAt(0) == "'") {
      sVarType = 'string';
    } else if (sValue == 'true' || sValue == 'false') {
      sVarType = 'string';
    } else if (sValue == 'null') {
      sVarType = 'mixed';
    } else if (sValue == 'array') {
      sVarType = 'array';
    } else if (sValue.match(/^\d+;$/)) {
      sVarType = 'integer';
    } else if (sValue.match(/^\d+\.\d+;$/)) {
      sVarType = 'float';
    }
    
    var result = new Array();
    result['varname'] = trim(regs[2]);
    result['vartype'] = sVarType; 
    
    if (regs[1] == 'private' || regs[1] == 'protected') {
      result['access'] = regs[1];
    } else {
      result['access'] = 'public';
    }
    return result;
  } else {
    return false;
  }
}

function getFunctionParams(sLine)
{
  var result = new Array();
  var aParams = sLine.split(',');
  for(var idx in aParams) {
    var aParam = new Array();
    var aTmp = aParams[idx].split('=');    
    if (aTmp.length > 1){
    
      var sValue = trim(aTmp[1].toLowerCase());
      var sVarType = '';
      if (sValue == '') {
        sVarType = '';
      } else if (sValue.charAt(0) == '"' || sValue.charAt(0) == "'") {
        sVarType = 'string';
      } else if (sValue == 'true' || sValue == 'false') {
        sVarType = 'boolean';
      } else if (sValue == 'null') {
        sVarType = 'mixed';
      } else if (sValue.match(/^\d+$/)) {
        sVarType = 'integer';
      } else if (sValue.match(/^\d+\.\d+$/)) {
        sVarType = 'float';
      }
      aParam['varvalue'] = trim(aTmp[1]);
      aParam['vartype'] = sVarType; 
      aParam['varname'] = trim(aTmp[0]); 
    } else {
      aParam['varname'] = aParams[idx];
      aParam['vartype'] = '';       
    }
    result[result.length] = aParam;
  }
  return result;
}

function getLineIndent(sLine)
{
  var regs = sLine.match(/^(\s*)/i);
  if (regs) {
    return regs[1].length;
  } else {
    return 0;
  }
}

var doc = application.document();
if (doc) {
  var content = doc.text;
  var linestart = doc.selstart-1;
  while ((linestart >= 0) && (content.charCodeAt(linestart) != 10)) {
    linestart--;
  }
  var lineend = doc.selstart;
  while ((lineend < content.length) && (content.charCodeAt(lineend) != 10)) {
    lineend++;
  }
  var line = content.substring(linestart+1, lineend);

  if(trim(line) != '') {
    var type = getLineType(line);
    if (type == false) {
      application.showMessage('No function, class, var, define, include or require.');
    }
    
    var phpdoc = '';
    
    switch (type) {

      case TYPE_FUNCTION :
        var aRet=getFunctionDetails(line);
        if(!aRet){
          application.showMessage('Function line not valid');
        } else {
          if(aRet['params']==''){
            noParams=true;
          } else {
            aParams=getFunctionParams(aRet['params']);
            noParams=false;
          }
          phpdoc = "/"+"**\n";
          phpdoc += "* \n";
          phpdoc += "*\n";
          if (!noParams) {
            for(var idx in aParams) {
              var sParam = aParams[idx];
              if (sParam['vartype'] && trim(sParam['vartype']) != '') {
                phpdoc += '* @param '+trim(sParam['vartype'])+' '+trim(sParam['varname'])+
                  " optional, default value "+sParam['varvalue']+"\n";
              } else {
                phpdoc += '* @param '+trim(sParam['varname'])+"\n";
              }
            }
          }
          phpdoc += "* @access "+aRet['access']+"\n";
          phpdoc += "* @return\n";
          phpdoc += "*"+"/\n";
        }
        break;

      case TYPE_VAR :
        phpdoc = "/"+"**\n";
        phpdoc += "* \n";
        phpdoc += "* @var ";
        var aRet = getVarDetails(line);
        if (aRet) {
          phpdoc += aRet['vartype'];
          if (aRet['access'] != 'public') {
            phpdoc += "\n* @access "+aRet['access'];
          }
        }
        phpdoc += "\n";
        phpdoc += "*"+"/\n";
        break;

      case TYPE_CLASS :
        phpdoc = "/"+"**\n";
        phpdoc += "* \n";
        phpdoc += "* \n";
        phpdoc += "*"+"/\n";
        break;

      case TYPE_DEFINE :
        phpdoc = "/**\n";
        phpdoc += "* \n";
        phpdoc += "*/\n";
        break;

      case TYPE_INCLUDE :
        phpdoc = "/**\n";
        phpdoc += "* \n";
        phpdoc += "*/\n";
        break;

      case TYPE_FILE :
        if (linestart <= 0) {
          var module = doc.fileName;
          var filename = module;
          var regs = module.match(/(([^\/\\]+)\.\w+)$/);
          if (regs) {
            module = regs[2];
            filename = regs[1];
          }
          phpdoc = "\n/"+"**\n";
          phpdoc += "* \n";
          phpdoc += "* \n";
          phpdoc += "* @module "+module+"\n";
          phpdoc += "* @author "+AUTHOR+"\n";
          phpdoc += "* @version ";
          if (INSERT_CVS_VERSION) {
            phpdoc += "$Id: "+filename+",v 0.0 00.00.0000 00:00:00 "+CVS_USER+" Exp $";
          }
          phpdoc += "\n";
          phpdoc += "*"+"/\n";
          
          // insert after line
          doc.selstart = linestart+line.length+1;
          doc.sellength = 0;
          doc.seltext = phpdoc;
      
          // move cursor
          doc.selstart = linestart+line.length+8;
          doc.sellength = 0;
          
          // nothing to insert any more
          phpdoc = '';
        }
    }

    if (phpdoc != '') {
      // calc indent and modify lines
      var indent = getLineIndent(line);
      var it = '';
      for (var i = 1; i <= indent; i++) {
        it += ' ';
      }
      var pt = phpdoc.split("\n");
      phpdoc = '';
      for (var idx in pt) {
        phpdoc += it+pt[idx]+"\n";
      }

      // insert before line
      doc.selstart = linestart+1;
      doc.sellength = 0;      
      doc.seltext = rtrim(phpdoc)+"\n";
      doc.sellength = 0;

      // move cursor
      doc.selstart = linestart+(2*indent)+7;
      doc.sellength = 0;
    }
  }
}