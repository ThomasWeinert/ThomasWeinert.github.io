/////////////////////////////////////////
// SimpleTable
//
// Copyright 2004 by Active-4.com
// http://www.active-4.com
// Code by Armin Ronacher
// armin.ronacher@active-4.com
/////////////////////////////////////////

var app = application;
var doc = app.document;

if(doc) {
    if(doc.sellength > 0) {
        if(app.editorLanguage == "de") {
                var trenner = app.inputDlg("Trennzeichen", "Gib bitte ein Trennzeichen f�r die einzelnen Zellen ein.", ";");
        } else {
                var trenner = app.inputDlg("Seperator", "Enter a seperator for the cells.", ";");
        }
        var text = doc.selText;
        var output = "";

        for(x=0; x<text.length; x++) {
            if (text.charAt(x) == trenner) {
                output = output + "</td><td>";
            }
            else if (text.charAt(x) == "\n") {
                output = output + "</td></tr>\n  <tr>";
            }
            else {
                output = output + text.charAt(x);
            }
        }

        //Tabelle ausgeben
        doc.seltext = "<table>\n  <tr><td>"+output+"</td></tr>\n</table>";
    }
}