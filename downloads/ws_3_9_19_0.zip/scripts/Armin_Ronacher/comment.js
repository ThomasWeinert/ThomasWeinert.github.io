/////////////////////////////////////////
// Auskommentieren von Bl�cken
//
// Copyright 2004 by Active-4.com
// http://www.active-4.com
// Code by Armin Ronacher
// armin.ronacher@active-4.com
/////////////////////////////////////////

//Variablen
var app = application;
var doc = app.document;
var bracket_left = new Array(4);
var bracket_right = new Array(4);

if(doc) {
    //Modus auslesen
    var profile = doc.fileProfile;

    //Klammerstil
    bracket_left[0] = "/* ";
    bracket_right[0] = " */";

    bracket_left[1] = "<!-- ";
    bracket_right[1] = " //-->";

    bracket_left[2] = "<!-- ";
    bracket_right[2] = " -->";

    bracket_left[3] = "<!--";
    bracket_right[3] = "-->";

    //Kommentieren / Kommentar entfernen.
    if(doc.sellength > 0)  {
        var text = doc.selText;
        var output = "";
        var found = false;

        //Nach den Brackets durchsuchen
        for (i=0; i<bracket_left.length; i++) {
            if ((text.substr(0, bracket_left[i].length) == bracket_left[i]) &&
                (text.substr(text.length-bracket_right[i].length, bracket_right[i].length) == bracket_right[i])) {
                //Vorne stutzen:
                output = text.substr(bracket_left[i].length, text.length-bracket_left[i].length);
                //Hinten stutzen
                output = output.substr(0, output.length-bracket_right[i].length);
                //Gefunden!
                found = true;
                break;
            }
        }
        //Konnte kein Kommentar finden
        //Also setze ein Kommentar
        if (!found) {
            if (profile == "JavaScript" || profile == "PHP" || profile == "CSS" || profile == "Java" || profile == "MySQL" || profile == "PL/SQL") {
                output = bracket_left[0] + text + bracket_right[0];
            }
            else if (profile == "HTML") {
                output = bracket_left[2] + text + bracket_right[2];
            }
        }

        //Neuen Text ausgeben
        doc.seltext = output;
    }
}