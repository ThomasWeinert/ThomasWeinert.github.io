////////
//  XML formatted 1.0
//  supported languages: all
//  
//  (c) Reinier van Loon 2004
//  http://www.2share.com
//  reinier@2share.com
//
//  note: it took about a minute to format 
//  htmlbtn.xml (51 KB) on my 1.6 GHz 512 MB laptop
//  which still is faster than doing it manually :-)
////

var index;
var xmltext;
var tokentype;
var level;

function editorIsOpen() {
  return (application && application.document && application.document.text.length > 1);
}

function xml_token() {
  var slash=0;
  var c = null;
  var i = 0,  j = 0;
  for(i = index; i < xmltext.length; i++) {
    c = xmltext.charAt(i);
    if (c=="<") {
      break;
    }
    if (c==" ") continue;
    if (c=="\n") continue;
    if (c=="\r") continue;
    break;
  }
  if (c=="<") {
    for(j = i; j < xmltext.length; j++) {
      c = xmltext.charAt(j);
      if (c==">") {
        break;
      }
      if (c=="/") {
        slash=j;
      }
    }
    var tt = slash + 1;
    if (tt==j) {  /* <xxxxxx /> */
      tokentype = 'fulltag';
    }
    else {
      tt = slash - 1;
      if (tt==i) {  // </xxxxxx>
        tokentype = 'endtag';
        level--;
      }
      else {
        tokentype = 'begintag';   // <xxxxx>
        level++;
      }
    }
    index = j + 1;
    return xmltext.substring(i,j+1);
  }
  else {
    for(j = i; j < xmltext.length; j++) {
      c = xmltext.charAt(j);
      if (c=="<") {
        break;
      }
    }
    index = j;
    tokentype = 'value';
    return xmltext.substring(i,j);
  }
}

function xml_formatted(t) {
  var new_text = "";
  var prev_token = "";
  var prev_tokentype = "";
  xmltext = t;
  index = 0;
  level = 0;
  application.showMessage(xmltext.length);
  while (index < xmltext.length) {
    token = xml_token();
    //application.messageDlg(3,tokentype+" index="+index+" "+token);
    if (tokentype=="value") {
      new_text += prev_token;
    }
    else {
      if (prev_tokentype=="value") {
        new_text += prev_token;
      }
      else {
        if (prev_tokentype=="begintag" && tokentype=="endtag") {
          new_text += prev_token;
        }
        else {
          if (prev_tokentype=="endtag" && tokentype=="endtag") {
            new_text += prev_token + "\n";
            for (x=0; x<level;x++) new_text += "  ";
          }
          else {
            if (prev_tokentype!="") {
              new_text += prev_token + "\n";
              for (x=1; x<level;x++) new_text += "  ";
            }
          }
        }
      }
    }
    prev_token = token;
    prev_tokentype = tokentype;
  }
  new_text += token;
  return new_text;
}

// Main
if(editorIsOpen()) {
  var new_text = xml_formatted(application.document.text);
  application.document.text = new_text;
}