////////
//  open file at cursor 1.0
//  supported languages: PHP
//
//  (c) Reinier van Loon 2004
//  http://www.2share.com
//  reinier@2share.com
////
var common_folders = "includes,include,inc,common";
var folder_search_up = 3;

function editorIsOpen() {
  return (application && application.document && application.document.text.length > 1);
}
function startOfLine(charIndex) {
  var doc = application.document;
  var text = application.document.text;
  var firstCharIndex = 0;
  var i = charIndex;
  while(i > firstCharIndex) {
    c = text.substr(i, 1);
    if(c == "\n") {
      return i+1;
    }
    i--;
  }
  return firstCharIndex;
}
function endOfLine(charIndex) {
  var doc = application.document;
  var text = application.document.text;
  var lastCharIndex = application.document.text.length;
  var i = charIndex;
  while(i <= lastCharIndex) {
    c = text.substr(i, 1);
    if(c == "\n") {
      return i;
    }
    i++;
  }
  return lastCharIndex;
}
function lineText(charIndex) {
  var text = application.document.text;
  var from = startOfLine(charIndex);
  var to = endOfLine(charIndex);
  return text.substring(from, to);
}
function lineContainsRequireOrInclude(charIndex) {
  var s = lineText(charIndex);
  if (s.indexOf("require")>=0) {
    return true;
  }
  if (s.indexOf("include")>=0) {
    return true;
  }
  return false;
}
function firstStringInLine(charIndex) {
  var s = lineText(charIndex);
  var i = s.indexOf("\"");
  if (i<0) {
    i = s.indexOf("'");
    if (i<0) {
      return "";
    }
    j = s.lastIndexOf("'");
    if (j<0) {
      return "";
    }
    return s.substring(i+1,j);
  }
  j = s.lastIndexOf("\"");
  if (j<0) {
    return "";
  }
  return s.substring(i+1,j);
}
function fileAlreadyOpen(s) {
  return fileIn(s, application.files());
}
function showOpenFile(s) {
  return showFileIn(s, application.files());
}
function fileInHistory(s) {
  return fileIn(s, application.filesHistory());
}
function showFileInHistory(s) {
  return showFileIn(s, application.filesHistory());
}
function fileIn(s, arr) {
  a = arr.split(",");
  for(i = 0; i < a.length; i++) {
    if (a[i].indexOf(s)>0) {
      return true;
    }
  }
  return false;
}
function showFileIn(s, arr) {
  a = arr.split(",");
  for(i = 0; i < a.length; i++) {
    if (a[i].indexOf(s)>0) {
      e = a[i];
      i = e.indexOf("\"");      // strip any leading and
      j = e.lastIndexOf("\"");  // trailing quote otherwise
      if (j>i) {
        d = e.substring(i+1,j); // document is not shown
        application.openDocument(d);
      } else {
        application.openDocument(e);
      }
      return true;
    }
  }
}
function openFromCommonFolders(s) {
  var d = application.projectDirectory;
  var up = "";
  for(u = 0; u < folder_search_up; u++) {
    a = common_folders.split(",");
    for(i = 0; i < a.length; i++) {
      var p = d + up + a[i] + "\\" + s;
      if (application.openDocument(p)) {
        return true;
      }
    }
    up = up + "..\\";
  }
  return false;
}
// Main
if(editorIsOpen()) {
  var doc = application.document;
  if (lineContainsRequireOrInclude(doc.selstart)) {
    var s = firstStringInLine(doc.selstart);
    if (fileAlreadyOpen(s)) {
      showOpenFile(s);
    } else {
/*       if (fileInHistory(s)) {
        showFileInHistory(s);
      } else { */
        if (!openFromCommonFolders(s)) {
          application.showMessage("Could not open " + s);
        }
/*       } */
    }
  }
}