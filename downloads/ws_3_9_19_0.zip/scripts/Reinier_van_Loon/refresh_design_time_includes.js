////////
//  refresh design time include 1.0
//  supported languages: PHP
//
//  (c) Reinier van Loon 2004
//  http://www.2share.com
//  reinier@2share.com
////

var index;
var old_text;
var tokentype;
var level;

function editorIsOpen() {
  return (application && application.document && application.document.text.length > 1);
}
function isDesignTimeInclude(s) {
  if (s.indexOf("<!--dti")>=0) {
    return true;
  }
  if (s.indexOf("<!--esi")>=0) {
    return true;
  }
  return false;
}
function endOfDesignTimeInclude(s) {
  if (s.indexOf("<!--/dti")>=0) {
    return true;
  }
  if (s.indexOf("<!--/esi")>=0) {
    return true;
  }
  return false;
}
function nextToken() {
  var exclamation_mark=0;
  var c = null;
  var i = 0,  j = 0;
  for(i = index; i < old_text.length; i++) {
    c = old_text.charAt(i);
    if (c=="<") {
      break;
    }
  }
  if (c=="<") {
    for(j = i; j < old_text.length; j++) {
      c = old_text.charAt(j);
      if (c==">") {
        break;
      }
      if (c=="!") {
        exclamation_mark=j;
      }
    }
    var tt = exclamation_mark - 1;
    if (tt==i) {  /* <!xxxxxx > */
      tokentype = 'comment';
    }
    else {
      tokentype = 'tag';
    }
    index = j + 1;
    return old_text.substring(i,j+1);
  }
  else {
    for(j = i; j < old_text.length; j++) {
      c = old_text.charAt(j);
      if (c=="<") {
        break;
      }
    }
    index = j;
    tokentype = 'value';
    return old_text.substring(i,j);
  }
}
function processDesignTimeInclude(s) {
  var answer = "";
  var t;
  while ( index < old_text.length ) {
    t = nextToken();
    if ( endOfDesignTimeInclude( t ) ) {
      answer += s;
      answer += contentsOfDesignTimeInclude( s );
      answer += t;
      break;
    }
  }
  return answer;
}
function contentsOfDesignTimeInclude(s) {
  var contents = "";
  var d = application.projectDirectory();
  if (isEditorSideInclude( s )) {
    var fn = d + fileNameEditorSideInclude( s );
    //application.showMessage("Including esi " + fn);
    if (application.openDocument( fn ) ) {
      contents = application.document.text;
    } else {
      application.showMessage("Could not open " + fn);
    }
  } else {
    var fn = d + fileNameDesignTimeInclude( s );
    //application.showMessage("Including dti " + fn);
    // assume dti (copy text between <body> and </body>)
    if (application.openDocument( fn ) ) {
      contents = application.document.text;
      var i = contents.indexOf('<body');
      var j = contents.indexOf('</body');
      contents = contents.substring(i+5,j);
      i = contents.indexOf('>');
      contents = contents.substring(i+1,j); // j is too large but ok
    } else {
      application.showMessage("Could not open " + fn);
    }
  }
  return contents;
}
function isEditorSideInclude( s ) {
  return s.indexOf("<!--esi")>=0;
}

function fileNameEditorSideInclude( s ) {
  var i = s.indexOf("\"");
  var j = s.lastIndexOf("\"");
  return s.substring(i+1,j);
}
function fileNameDesignTimeInclude( s ) {
  var i = s.indexOf("\"");
  var j = s.lastIndexOf("\"");
  return s.substring(i+1,j);
}


// Main
if(editorIsOpen()) {
  var doc = application.document;
  var fn = application.document.fileName();
  var txt = "";
  var t;
  old_text = doc.text;
  index = 0;
  while ( index < old_text.length ) {
    t = nextToken();
    //application.showMessage("txt=" + txt);
    if ( isDesignTimeInclude( t ) ) {
      txt += processDesignTimeInclude( t );
    } else {
      txt += t;
    }
  }
  application.openDocument(fn);
  doc.text = txt;
}