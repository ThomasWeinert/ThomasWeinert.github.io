#include "stdafx.h"
#include "ws.h"

typedef char *( __stdcall *PLUGINCALLBACK)(int,int,int);
PLUGINCALLBACK fpPluginCallBack=NULL;
unsigned int PluginSystem;


int hextoint(char x)
{
//char WStr[2];
//WStr[0]=x;
//WStr[1]=0x0;
//MessageBox(NULL,WStr,"Hex2Int",MB_OK);
switch(x)
   {
   default  :
   case '0' : return  0;
   case '1' : return  1;
   case '2' : return  2;
   case '3' : return  3;
   case '4' : return  4;
   case '5' : return  5;
   case '6' : return  6;
   case '7' : return  7;
   case '8' : return  8;
   case '9' : return  9;
   case 'a' : 
   case 'A' : return 10;
   case 'b' : 
   case 'B' : return 11;
   case 'c' : 
   case 'C' : return 12;
   case 'd' : 
   case 'D' : return 13;
   case 'e' : 
   case 'E' : return 14;
   case 'f' : 
   case 'F' : return 15;
   }
}

char * CallBackToEditor(int Command, char *Buffer, int *rescode)
{
char *p;
//char WStr[20];
if(fpPluginCallBack)
   {
   p=(*fpPluginCallBack)(PluginSystem,Command,(int)Buffer);
   //MessageBox(NULL,p,p,MB_OK);
   *rescode= (hextoint( *(p+0) )*16)+ hextoint( *(p+1) );
   //sprintf(WStr,"rescode=%d",*rescode);
   //MessageBox(NULL,WStr,"Test",MB_OK);
   return p+2;
   }
return NULL;
}


void SetCallBack(int TPlugin_CallBack, int iPluginSystem)
{
fpPluginCallBack=(PLUGINCALLBACK)TPlugin_CallBack;
PluginSystem=iPluginSystem;
}


void GetDLLFilename(char *modname, HINSTANCE x)
{
GetModuleFileName(x,modname,MAX_PATH);
}



// srp_cmd_openfile
bool Callback_OpenFile(char *Filename, int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_openfile,Filename,rescode))?true:false;
} 
// srp_cmd_newfile
bool Callback_NewFile(char *TemplateData, int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_newfile,TemplateData,rescode))?true:false;
} 
// srp_cmd_savefile
bool Callback_SaveFile(char *Filename, int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_savefile,Filename,rescode))?true:false;
} 
// srp_cmd_gotoline
bool Callback_GotoLine(int LineNo, int *rescode)
{
char WStr[64];
return atoi(CallBackToEditor(srp_cmd_gotoline,itoa(LineNo,WStr,10),rescode))?true:false;
} 
// srp_cmd_getfilename
char *Callback_GetFilename(int *rescode)
{
return CallBackToEditor(srp_cmd_getfilename,NULL,rescode);
} 
// srp_cmd_getfilecount
int Callback_GetFileCount(int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_getfilecount,NULL,rescode));
} 
// srp_cmd_getselstart
int Callback_GetSelStart(int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_getselstart,NULL,rescode));
} 
// srp_cmd_getsellength
int Callback_GetSelLength(int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_getsellength,NULL,rescode));
} 
// srp_cmd_getseltext
char *Callback_GetSelText(int *rescode)
{
return CallBackToEditor(srp_cmd_getseltext,NULL,rescode);
} 
// srp_cmd_setseltext
bool Callback_SetSelText(char *Data, int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_setseltext,Data,rescode))?true:false;
} 
// srp_cmd_gettext
char *Callback_GetText(int *rescode)
{
return CallBackToEditor(srp_cmd_gettext,NULL,rescode);
} 
// srp_cmd_settext
bool Callback_SetText(char *Data,int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_settext,Data,rescode))?true:false;
} 
// srp_cmd_editorname
char *Callback_EditorName(int *rescode)
{
return CallBackToEditor(srp_cmd_editorname,NULL,rescode);
} 
//srp_cmd_editorversion
char *Callback_EditorVersion(int *rescode)
{
return CallBackToEditor(srp_cmd_editorversion,NULL,rescode);
}  
//srp_cmd_editorlanguage                                        
char *Callback_EditorLanguage(int *rescode)
{
return CallBackToEditor(srp_cmd_editorlanguage,NULL,rescode);
}  
//srp_cmd_editorhtmldocu
char *Callback_EditorHTMLDocu(int *rescode)
{
return CallBackToEditor(srp_cmd_editorhtmldocu,NULL,rescode);
} 
//srp_cmd_editorphpdocu
char *Callback_EditorPHPDocu(int *rescode)
{
return CallBackToEditor(srp_cmd_editorphpdocu,NULL,rescode);
}  
//srp_cmd_plugindir
char *Callback_PluginDir(int *rescode)
{
return CallBackToEditor(srp_cmd_plugindir,NULL,rescode);
}  
//srp_cmd_projectdir
char *Callback_ProjectDir(int *rescode)
{
return CallBackToEditor(srp_cmd_projectdir,NULL,rescode);
}  
//srp_cmd_browserdir
char *Callback_BrowserDir(int *rescode)
{
return CallBackToEditor(srp_cmd_browserdir,NULL,rescode);
}  
//srp_cmd_openfiles
void Callback_OpenFiles(char *Files, unsigned int max, int *rescode)
{
char *p;
p=CallBackToEditor(srp_cmd_openfiles,NULL,rescode);
if(strlen(p)<=max)strcpy(Files,p);
}  
//srp_cmd_historyfiles
void Callback_HistoryFiles(char *Files, unsigned int max, int *rescode)
{
char *p;
p=CallBackToEditor(srp_cmd_historyfiles,NULL,rescode);
if(strlen(p)<=max)strcpy(Files,p);
}  
//srp_cmd_browsers
void Callback_Browsers(char *Files, unsigned int max, int *rescode)
{
char *p;
p=CallBackToEditor(srp_cmd_browsers,NULL,rescode);
if(strlen(p)<=max)strcpy(Files,p);
}  
//srp_cmd_modifiedfiles
void Callback_ModifiedFiles(char *Files, unsigned int max, int *rescode)
{
char *p;
p=CallBackToEditor(srp_cmd_modifiedfiles,NULL,rescode);
if(strlen(p)<=max)strcpy(Files,p);
}
//srp_cmd_fileprofiles
void Callback_FileProfiles(char *FileProfiles, unsigned int max, int *rescode)
{
char *p;
p=CallBackToEditor(srp_cmd_fileprofiles,NULL,rescode);
if(strlen(p)<=max)strcpy(FileProfiles,p);
}
//srp_cmd_setfileprofilebyname
bool Callback_SetFileProfileByName(char *FileProfileName, int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_setfileprofilebyname,FileProfileName,rescode))?true:false;
}
//srp_cmd_setfileprofilebyextension
bool Callback_SetFileProfileByExt(char *FileExtension, int *rescode)
{
return atoi(CallBackToEditor(srp_cmd_setfileprofilebyextension,FileExtension,rescode))?true:false;
}
//srp_cmd_getfileprofilename
char *Callback_GetFileProfileName(int *rescode)
{
return NULL;
}
