// WSPlugin.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <stdlib.h>
#include "resource.h"
#include "ws.h"

HINSTANCE globalInstance;


int gselstart=0;
int gsellength=0;


BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{

globalInstance=(HINSTANCE)hModule;
//MessageBox(NULL,"Test...","Test...",MB_OK);
switch (ul_reason_for_call)
   {
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
        
		  break;
   }
return TRUE;
}





int __stdcall Start_Plugin(int hwnd, //Handle of Mainform
                           int iPluginSystem, //Handle of pluginsystem component
                           int TPlugin_CallBack //Callbackfunction
                      )
{

int retw;

//just a simply buffer...
char text[1024*1024];

int sellength=0;
int selstart=0;

SetCallBack(TPlugin_CallBack,iPluginSystem);

//Get selection start and length
selstart=Callback_GetSelStart(&retw);
sellength=Callback_GetSelLength(&retw);

//Example of getting selected Text only
strcpy(text,Callback_GetSelText(&retw));

//Example of getting complete Text
//strcpy(text,Callback_GetText(&retw));

//Do what ever you want here...


//Returned buffer replaces whole file
//Callback_SetText(Arbeitspuffer,&retw);

//Returnen buffer replaces only selection
//Callback_SetSelText(Arbeitspuffer,&retw);

return 0;
}



int __stdcall Init_InterfaceVersion(void)
{
return 3;
}





char * __stdcall  pluginInfo( int ask)
{
switch(ask)
    {
    case srp_Info_Title         : return "WeaverSlave C/C++ Plugin";
    case srp_Info_Group         : return "GROUP";
    case srp_Info_Version       : return "0.1";
    case srp_Info_Description   : return "Interface for WeaverSlave Plugin for C/C++.";
    case srp_Info_Licence       : return "";
    case srp_Info_Copyright     : return "(C) 2004 ESDS Austria";
    }
return "unsupported."; 
}
