//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WSPlugin.rc
//
#define IDD_OPTIONS                     101
#define IDI_ICON1                       102
#define IDC_CHECKPHP                    1000
#define IDC_RADIOECHO                   1001
#define IDC_RADIOPRINT                  1002
#define IDC_CHECKKEEPLF                 1003
#define IDC_EDITFUNCTION                1004
#define IDC_CHECKHARDLF                 1005
#define IDC_EDITHARDLF                  1006
#define IDC_RADIO1                      1007
#define IDC_TEXTINFO                    1007
#define IDC_RADIOHERE                   1008
#define IDC_FUNCTIONTEXT                1009
#define IDC_BUTTON                      1011
#define IDC_CHECKNEWFILE                1012
#define IDC_CHECKCOMMENT                1014
#define IDC_CHECKBEAUTY                 1015
#define IDC_CHECKLINE                   1016
#define IDC_RADIOJS                     1017
#define IDC_CHECKINCLUDE                1018
#define IDC_CHECKREQUIRE                1019
#define IDC_COMBOFILE                   1020
#define IDC_CHECKCALL                   1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
