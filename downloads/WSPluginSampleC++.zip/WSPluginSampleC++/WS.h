
  
  
// result values
         //plugin has no informations (used by info-dialog)
#define  srp_Error_NoInfos          (-4)
         //plugin needs a file on hard disk 
#define  srp_Error_NeedSavedFile    (-3) 
         //plugin needs a file
#define  srp_Error_NeedFile         (-2) 
         //general error
#define  srp_Error                  (-1) 
         //no error
#define  srp_OK                     0        
         //Used in HE 5 Plugins
#define  srp_SelectedText           1 
         //Used in HE 5 Plugins
#define  srp_EditorText             2 

  // info ids
#define  srp_Info_Title             0
#define  srp_Info_Group             1
#define  srp_Info_Version           2
#define  srp_Info_Description       3
#define  srp_Info_Licence           4
#define  srp_Info_Copyright         5

  //commands
         //open a file from disk
#define  srp_cmd_openfile                    1 
         //create a new file
#define  srp_cmd_newfile                     2 
         //goto this line
#define  srp_cmd_gotoline                    3 
         //get filename of active document
#define  srp_cmd_getfilename                 4 
         //get count of opened files
#define  srp_cmd_getfilecount                5 
         //get selection start
#define  srp_cmd_getselstart                 6 
         //get selection end
#define  srp_cmd_getsellength                7 
         //get selected text
#define  srp_cmd_getseltext                  8 
         //set selected text
#define  srp_cmd_setseltext                  9 
         //get all text
#define  srp_cmd_gettext                     10 
         //set all text (selection lost)
#define  srp_cmd_settext                     11 
         //get editor name
#define  srp_cmd_editorname                  12 
         //get editor version
#define  srp_cmd_editorversion               13 
         //get actual language of editor (en, de, pl, ...)
#define  srp_cmd_editorlanguage              14 
         //filename of html documentation
#define  srp_cmd_editorhtmldocu              15 
         //filename of php documentation
#define  srp_cmd_editorphpdocu               16 
         //get plugin directory
#define  srp_cmd_plugindir                   17 
         //get project directory (path of actual file at the moment)
#define  srp_cmd_projectdir                  18 
         //get browser directory (path of internal file browser)
#define  srp_cmd_browserdir                  19 
         //get filenames of all opened files
#define  srp_cmd_openfiles                   20 
         //get filenames in history
#define  srp_cmd_historyfiles                21 
         //get browsers
#define  srp_cmd_browsers                    22 
         //get modified files
#define  srp_cmd_modifiedfiles               23 
         //save file
#define  srp_cmd_savefile                    24 
         //file profiles list
#define  srp_cmd_fileprofiles                25 
         //set file profile by name
#define  srp_cmd_setfileprofilebyname        26 
         // set file profile by extension
#define  srp_cmd_setfileprofilebyextension   27 
         // get current file profile name
#define  srp_cmd_getfileprofilename          28 
 






  //callback errors
         //no valid callbackfunction
#define  srp_cmderr_nocallback      101 
         //error in pluginsystem
#define  srp_cmderr_pluginsystem    102 
         //editor can not handle commands
#define  srp_cmderr_nothandled      103 
         //command is not implemented       
#define  srp_cmderr_notimplemented  104 

  //callback results
         //all ok - command done
#define  srp_cmdres_ok              0 
         //command requires a file, but here is no file
#define  srp_cmdres_nofile          1 
         //command requires a textfile, but here is only a image
#define  srp_cmdres_notextfile      2 
         //command not done
#define  srp_cmdres_false           3

void SetCallBack(int TPlugin_CallBack,int iPluginSystem);
char * CallBackToEditor(int Command, char *Buffer, int *rescode);


void GetDLLFilename(char *modname, HINSTANCE x);

// srp_cmd_openfile
bool Callback_OpenFile(char *Filename, int *rescode); 
// srp_cmd_newfile
bool Callback_NewFile(char *TemplateData, int *rescode); 
// srp_cmd_savefile
bool Callback_SaveFile(char *Filename, int *rescode); 
// srp_cmd_gotoline
bool Callback_GotoLine(int LineNo, int *rescode); 
// srp_cmd_getfilename
char *Callback_GetFilename(int *rescode); 
// srp_cmd_getfilecount
int Callback_GetFileCount(int *rescode); 
// srp_cmd_getselstart
int Callback_GetSelStart(int *rescode); 
// srp_cmd_getsellength
int Callback_GetSelLength(int *rescode); 
// srp_cmd_getseltext
char *Callback_GetSelText(int *rescode); 
// srp_cmd_setseltext
bool Callback_SetSelText(char *Data, int *rescode); 
// srp_cmd_gettext
char *Callback_GetText(int *rescode); 
// srp_cmd_settext
bool Callback_SetText(char *Data, int *rescode); 
// srp_cmd_editorname
char *Callback_EditorName(int *rescode); 
//srp_cmd_editorversion
char *Callback_EditorVersion(int *rescode);  
//srp_cmd_editorlanguage                                        
char *Callback_EditorLanguage(int *rescode);  
//srp_cmd_editorhtmldocu
char *Callback_EditorHTMLDocu(int *rescode); 
//srp_cmd_editorphpdocu
char *Callback_EditorPHPDocu(int *rescode);  
//srp_cmd_plugindir
char *Callback_PluginDir(int *rescode);  
//srp_cmd_projectdir
char *Callback_ProjectDir(int *rescode);  
//srp_cmd_browserdir
char *Callback_BrowserDir(int *rescode);  
//srp_cmd_openfiles
void Callback_OpenFiles(char *Files, unsigned int max, int *rescode);  
//srp_cmd_historyfiles
void Callback_HistoryFiles(char *Files, unsigned int max, int *rescode);  
//srp_cmd_browsers
void Callback_Browsers(char *Files, unsigned int max, int *rescode);  
//srp_cmd_modifiedfiles
void Callback_ModifiedFiles(char *Files, unsigned int max, int *rescode);  
//srp_cmd_fileprofiles
void Callback_FileProfiles(char *FileProfiles, unsigned int max, int *rescode); 
//srp_cmd_setfileprofilebyname
bool Callback_SetFileProfileByName(char *FileProfileName, int *rescode); 
//srp_cmd_setfileprofilebyextension
bool Callback_SetFileProfileByExt(char *FileExtension, int *rescode); 
//srp_cmd_getfileprofilename
char *Callback_GetFileProfileName(int *rescode);  
